package com.pricer.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.Test;

import com.pricer.basket.children.AbstractFruit;
import com.pricer.basket.children.Apples;
import com.pricer.basket.children.Bananas;
import com.pricer.basket.children.Lemons;
import com.pricer.basket.children.Oranges;
import com.pricer.basket.children.Peaches;
import com.pricer.basket.common.BasketValidator;
import com.pricer.basket.common.FruitEnum;
import com.pricer.basket.parent.BasketImp;
import com.pricer.basket.parent.IBasket;
import com.pricer.basket.princing.engine.IPricingEngine;
import com.pricer.basket.princing.engine.PricingEngineImpl;

public class PricerTester  {

	ExecutorService executor=Executors.newFixedThreadPool(10);
	IPricingEngine pricingEgine=new PricingEngineImpl();

	@Test
	public void test() throws Exception {
		Map<AbstractFruit,Integer> basketComposition=new HashMap<>();
		AbstractFruit bananas=new Bananas(FruitEnum.BANANAS.getCode(),2.0); //New banana with the price 2
		AbstractFruit lemons=new Lemons(FruitEnum.LEMONS.getCode(),10.0);//New lemon with the price 10		
		basketComposition.put(bananas, 8); // I added 10 bananas to the basket
		basketComposition.put(lemons, 3); // I added 3 lemons to the basket
		IBasket basket=new BasketImp(basketComposition);
		Double price=pricingEgine.price(basket, executor);
		//BasketValue = 2*8 + 10*3 = 46
		assertEquals(price, new Double(46));
	}
	@Test
	public void test2() throws Exception {
		Map<AbstractFruit,Integer> basketComposition=new HashMap<>();
		AbstractFruit apples=new Apples(FruitEnum.APPLES.getCode(),3.0);//New apple with the price 3
		AbstractFruit oranges=new Oranges(FruitEnum.ORANGES.getCode(),4.0);//New Oranges with the price 4
		AbstractFruit peaches=new Peaches(FruitEnum.PEACHES.getCode(),5.0);//New Oranges with the price 4
		basketComposition.put(apples, 1); // I added one apple to the basket
		basketComposition.put(oranges, 4);
		basketComposition.put(peaches, 2);
		IBasket basket=new BasketImp(basketComposition);
		Double price=pricingEgine.price(basket, executor);
		//BasketValue = 1*3 + 4*4 + 5*2 = 29
		assertEquals(price, new Double(29));
	}
	@Test
	public void test3() throws Exception {
		//This test is supposed to generate an exception as the Apple price is null 
		Map<AbstractFruit,Integer> basketComposition=new HashMap<>();
		AbstractFruit apples=new Apples(FruitEnum.APPLES.getCode(),null);// let s put null as a price of apples
		AbstractFruit oranges=new Oranges(FruitEnum.ORANGES.getCode(),4.0);
		AbstractFruit peaches=new Peaches(FruitEnum.PEACHES.getCode(),5.0);
		basketComposition.put(apples,1);
		basketComposition.put(oranges,4);
		basketComposition.put(peaches, 2);
		IBasket basket=new BasketImp(basketComposition);
		Double price=pricingEgine.price(basket, executor);
		//BasketValue = 1*3 + 4*4 + 5*2 = 29
		assertEquals(price, new Double(29));
	}
	@Test
	public void test4() throws Exception {
		//Testing the basket validator
		boolean isValid=BasketValidator.validate(null);
		assertEquals(isValid,false);
	}
	@Test
	public void test5() throws Exception {
		//Testing the basket validator
		Map<AbstractFruit,Integer> basketComposition=new HashMap<>();
		AbstractFruit apples=new Apples(FruitEnum.APPLES.getCode(),2.0);
		AbstractFruit oranges=new Oranges(FruitEnum.ORANGES.getCode(),4.0);
		AbstractFruit peaches=new Peaches(FruitEnum.PEACHES.getCode(),5.0);
		basketComposition.put(apples, null); // lets put null as quantity for apples
		basketComposition.put(oranges, 4);
		basketComposition.put(peaches, 2);
		IBasket basket=new BasketImp(basketComposition);
		boolean isValid=BasketValidator.validate(basket);
		assertEquals(isValid,false);
	}
}
