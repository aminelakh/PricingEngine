package com.pricer.basket.calculation.engine;

import java.util.concurrent.Callable;

import com.pricer.basket.parent.IBasket;
import com.project.pricer.basket.children.AbstractFruit;

public class ParallelPricingTask implements Callable<Double> {

	private AbstractFruit fruit;
	private Integer quantity;
	private IBasket basket;
	
	public ParallelPricingTask(AbstractFruit fruit,Integer quantity,IBasket basket){
		this.fruit=fruit;
		this.basket=basket;
		this.quantity=quantity;
	}
	@Override
	public Double call() throws Exception {
		if(fruit!=null && fruit.getPrice()==null){
			throw new Exception("The price can not be null for the fruit "+fruit.toString());
		}
		System.out.println("My worker id is :["+Thread.currentThread().getName()+ "] My task is : [pricing " +fruit.toString()+ "]");
		return basket.updateBasketPrice(fruit.getPrice()*quantity);
	}
}
