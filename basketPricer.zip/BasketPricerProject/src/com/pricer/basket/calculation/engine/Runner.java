package com.pricer.basket.calculation.engine;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Runner {

	public static void main(String[] args) throws Exception {
		
		System.out.println("........ START Parallel Basket Pricing ........");
		ExecutorService executor=Executors.newFixedThreadPool(10);
		IPricingEngine pricingEgine=new PricingEngineImpl();
		Double totalPrice=0.0;
		try {
			totalPrice=pricingEgine.price(BasketLoader.load(), executor);
		} catch (Exception e) {
			throw new Exception("Pricing can not be done ");
		}
		finally{
			executor.shutdown();
			while(!executor.isTerminated()){
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("The Basket total price is "+ totalPrice);
			System.out.println("........ END Parallel Basket Pricing ........");
		}
	}
}
