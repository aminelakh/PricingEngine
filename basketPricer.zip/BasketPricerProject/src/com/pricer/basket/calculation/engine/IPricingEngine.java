package com.pricer.basket.calculation.engine;

import java.util.concurrent.ExecutorService;

import com.pricer.basket.parent.IBasket;

public interface IPricingEngine {
	public Double price(IBasket basket,ExecutorService executor) throws  Exception	;	

}
