package com.pricer.basket.princing.engine;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.pricer.basket.common.BasketValidator;
import com.pricer.basket.parent.IBasket;

public class Runner {

	public static void main(String[] args) throws Exception {
		System.out.println("........ START Parallel Basket Pricing ........");
		ExecutorService executor=Executors.newFixedThreadPool(10);
		IPricingEngine pricingEgine=new PricingEngineImpl();
		Double totalPrice=0.0;
		IBasket basket=BasketLoader.load();// loading the basket + it's composition
		if(BasketValidator.validate(basket)){ //If the basket and it's composition are valid then we can price it.
			try {
				totalPrice=pricingEgine.price(basket, executor);
			} catch (Exception e) {
				executor.shutdownNow();
				throw new Exception("Pricing can not be done ");
			}
			finally{
				executor.shutdown();
				while(!executor.isTerminated()){
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println("The Basket total price is "+ totalPrice);
				System.out.println("........ END Parallel Basket Pricing ........");
			}
		}
		}
}
