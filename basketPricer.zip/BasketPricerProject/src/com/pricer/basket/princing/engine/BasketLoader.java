package com.pricer.basket.princing.engine;

import java.util.HashMap;
import java.util.Map;

import com.pricer.basket.children.AbstractFruit;
import com.pricer.basket.children.Apples;
import com.pricer.basket.children.Bananas;
import com.pricer.basket.children.Lemons;
import com.pricer.basket.children.Oranges;
import com.pricer.basket.children.Peaches;
import com.pricer.basket.common.FruitEnum;
import com.pricer.basket.parent.BasketImp;
import com.pricer.basket.parent.IBasket;

public class BasketLoader {
	
	public static IBasket load(){
		/*Just to simplify I considered that:
		 * The basket and the fruits have the same currency, no need to convert.
		 * The price is by unit and not by KG
	*/
		Map<AbstractFruit,Integer> basketComposition=new HashMap<>();
		
		AbstractFruit bananas=new Bananas(FruitEnum.BANANAS.getCode(),2.0); //New banana with the price 2
		AbstractFruit lemons=new Lemons(FruitEnum.LEMONS.getCode(),10.0);//New lemon with the price 10
		AbstractFruit apples=new Apples(FruitEnum.APPLES.getCode(),3.0);//New apple with the price 3
		AbstractFruit oranges=new Oranges(FruitEnum.ORANGES.getCode(),4.0);//New Oranges with the price 4
		AbstractFruit peaches=new Peaches(FruitEnum.PEACHES.getCode(),5.0);//New Oranges with the price 4
		
		basketComposition.put(bananas, 8); // I added 10 bananas to the basket
		basketComposition.put(lemons, 3); // I added 3 lemons to the basket
		basketComposition.put(apples, 1); // I added one apple to the basket
		basketComposition.put(oranges, 4);
		basketComposition.put(peaches, 2);
		//Total price = (2*8) +(10*3)+(3*1)+(4*4)+(5*2) =75
		return new BasketImp(basketComposition);
	}

}
