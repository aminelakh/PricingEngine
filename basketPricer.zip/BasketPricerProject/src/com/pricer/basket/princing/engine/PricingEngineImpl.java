package com.pricer.basket.princing.engine;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import com.pricer.basket.children.AbstractFruit;
import com.pricer.basket.parent.IBasket;

public class PricingEngineImpl implements IPricingEngine {

	@Override
	public Double price(IBasket basket,ExecutorService executor) throws Exception {
		if(basket!=null){
			Map<AbstractFruit,Integer> composition=basket.getBasketCompostion();
			if(composition!=null && !composition.isEmpty()){
				for(Entry<AbstractFruit,Integer> m:composition.entrySet()){
					AbstractFruit fruit=m.getKey();
					Integer quantity=m.getValue();
					//For each fruit we send its price and quantity to the thread pool.
					Future<Double> future=executor.submit(new ParallelPricingTask(fruit,quantity, basket));
					try {
						future.get();
					} catch (Exception e) {
						e.printStackTrace();
						throw e;
					}
				}
			}
		}
		return basket.getBasketPrice();
	}
}
