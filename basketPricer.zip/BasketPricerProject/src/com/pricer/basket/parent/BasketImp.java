package com.pricer.basket.parent;

import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.pricer.basket.children.AbstractFruit;

public class BasketImp implements IBasket{
	
	private Double price=0.0;
	private final Lock lock=new ReentrantLock();
	private Map<AbstractFruit,Integer> basketComposition; 	//Composition of the basket <Fruit Type, Quantity>
	
	public BasketImp(Map<AbstractFruit,Integer> basketComposition){
		this.basketComposition=basketComposition;
	}
	@Override
	public Double getBasketPrice() {
		return this.price;
	}
	@Override
	public Map<AbstractFruit,Integer> getBasketCompostion() {
		return basketComposition;
	}
	@Override
	public Double updateBasketPrice(Double toAdd) { // This method should be synchronized as it can be accessed by several threads at the same time.
		try{
			lock.lock();
			price=price+toAdd;
			return price;
		}finally{
			lock.unlock();
		}
	}
}
