package com.pricer.basket.parent;

import java.util.Map;

import com.project.pricer.basket.children.AbstractFruit;

public class BasketImp implements IBasket{
	
	private Double price=0.0;
	private final Object myLock=new Object();
	private Map<AbstractFruit,Integer> basketComposition; 	//Composition of the basket <Fruit Type, Quantity>
	
	public BasketImp(Map<AbstractFruit,Integer> basketComposition){
		this.basketComposition=basketComposition;
	}
	@Override
	public Double getBasketPrice() {
		return this.price;
	}
	@Override
	public Map<AbstractFruit,Integer> getBasketCompostion() {
		return basketComposition;
	}
	@Override
	public Double updateBasketPrice(Double toAdd) { // This method should be synchronized as it can be accessed by several threads at the same time.
		synchronized (myLock) {
			price=price+toAdd;
			return price;
		}
	}
}
