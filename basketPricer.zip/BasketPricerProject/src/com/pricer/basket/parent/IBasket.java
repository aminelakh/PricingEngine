package com.pricer.basket.parent;

import java.util.Map;

import com.project.pricer.basket.children.AbstractFruit;

public interface IBasket {
	
	public Double getBasketPrice();
	public Double updateBasketPrice(Double toAdd);
	public Map<AbstractFruit,Integer> getBasketCompostion();
	

}
