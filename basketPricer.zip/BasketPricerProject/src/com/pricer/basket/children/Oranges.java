package com.pricer.basket.children;

//Immutable class as it is used as a key in the MAP
public final class Oranges implements AbstractFruit {

	private final Double price;
	private final Integer fruitCode;
	
	public Oranges(Integer fruitCode,Double price){
		this.price=price;
		this.fruitCode=fruitCode;
	}
	@Override
	public String toString() {
		return "Oranges";
	}
	@Override
	public Double getPrice(){
		return this.price;
	}
	@Override
	public Integer getFruitCode() {
		return fruitCode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fruitCode == null) ? 0 : fruitCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Oranges other = (Oranges) obj;
		if (fruitCode == null) {
			if (other.fruitCode != null)
				return false;
		} else if (!fruitCode.equals(other.fruitCode))
			return false;
		return true;
	}
	

	
}
