package com.pricer.basket.children;


public interface AbstractFruit {
	public   Double getPrice();
	public  Integer getFruitCode();
	
}
