package com.pricer.basket.common;

import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import com.pricer.basket.children.AbstractFruit;
import com.pricer.basket.parent.IBasket;

public class BasketValidator {
	
	private static final Logger logger = Logger.getLogger("Info logging");
	
	public static boolean validate(IBasket basket){
		
		 boolean isValid=true;
		
		if(basket==null){
			logger.warning("Can not price a null basket");
			return false;
		}
		if(basket.getBasketCompostion()==null){
			logger.warning("Can not price a basket without a composition");
			return false;
		}
		if(basket.getBasketCompostion()!=null && basket.getBasketCompostion().isEmpty()){
			logger.warning("Can not price a basket with empty composition");
			return false;
		}
		Map<AbstractFruit,Integer> compo=basket.getBasketCompostion();
		for(Entry<AbstractFruit,Integer> e:compo.entrySet()){
			AbstractFruit fruit=e.getKey();
			Integer quantity=e.getValue();
			if(quantity==null || quantity.equals(0)){
				logger.warning("Quantity for the fruit "+fruit.toString()+ " can not be null or zero. Quantity "+quantity);
				isValid=false;
			}
		}
		return isValid;
	}

}
