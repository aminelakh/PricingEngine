package com.pricer.basket.common;

public enum FruitEnum {

	APPLES(111),
	BANANAS(222),
	LEMONS(333),
	ORANGES(444),
	PEACHES(555),
	APPLES_ORGANIC(666),
	OTHER_FRUIT(777);
	
	private Integer code;
	FruitEnum(Integer code) {
		this.code = code;
	}
	public Integer getCode(){
		return this.code;
  }
}
