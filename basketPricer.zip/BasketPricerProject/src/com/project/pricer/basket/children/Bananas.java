package com.project.pricer.basket.children;

//Immutable class as it is used as a key in the MAP
public final class Bananas extends AbstractFruit{

	private final Double price;
	public Bananas(Double price){
		super();
		this.price=price;
	}
	@Override
	public Double getPrice() {
		return this.price;
	}
	@Override
	public String toString() {
		return "Bananas";
	}

}
