package com.project.pricer.basket.children;

//Immutable class as it is used as a key in the MAP
public final class Apples extends AbstractFruit{
	
	private final Double price;
	public Apples(Double price){
		super();
		this.price=price;
	}
	@Override
	public Double getPrice() {
		return this.price;
	}
	@Override
	public String toString() {
		return "Apples";
	}

	

}
