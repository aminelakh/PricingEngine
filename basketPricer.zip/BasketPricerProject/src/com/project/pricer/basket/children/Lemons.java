package com.project.pricer.basket.children;

//Immutable class as it is used as a key in the MAP
public final class Lemons extends AbstractFruit {

	private final Double price;
	public Lemons(Double price){
		super();
		this.price=price;
	}
	@Override
	public String toString() {
		return "Lemons";
	}
	@Override
	public Double getPrice() {
		return this.price;
	}

}
