package com.project.pricer.basket.children;


public abstract class AbstractFruit {
	
	protected Integer fruitCode;

	public abstract Double getPrice();
	//The implementation of equals and hashCode is mandatory as AbstractFruit object is used as a key in the basket composition Map.
	// Two objects are equals when they have the same fruitCode (unique for the fruits from the same family).
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fruitCode == null) ? 0 : fruitCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractFruit other = (AbstractFruit) obj;
		if (fruitCode == null) {
			if (other.fruitCode != null)
				return false;
		} else if (!fruitCode.equals(other.fruitCode))
			return false;
		return true;
	}
}
